---
title: "优秀资源合集"
date: 2018-12-21 21:34:10
type: "resources"
---

## 导航/资源

[404导航]( https://no404.icu/)

[addog](http://www.addog.vip/)

[不死鸟](https://hao.su/)

[多吉搜索](https://www.dogedoge.com/)

[每日一学网](http://www.meiriyixue.cn/)

[喵容-精品软件](https://www.miaoroom.com/software)

[黑洞-技术教程](https://www.nulltm.com/tutorials)

[精品绿色便携软件](https://www.portablesoft.org/)

[w3cjava](http://www.w3cjava.com/)

[设计师网址导航](http://hao.uisdc.com/)

[优波设计](https://www.ubuuk.com/)

[46设计导航](http://www.46design.com/)

[工业设计导航](http://hao.shejipi.com/)

[牛大拿设计师导航](http://www.niudana.com/)

## 社区

[吾爱破解](https://www.52pojie.cn/)

[虫部落](https://www.chongbuluo.com/)

## 图书

[jiumodiary](https://www.jiumodiary.com/)

[扫地僧的橱柜](https://www.ebooksplan.club/)

[读书达人](http://www.dushudaren.com/)

[java人技术分享网](https://www.javaperson.com/)

[sobooks](https://sobooks.cc/)

[ebook资源网 ](https://skebooks.com/)

[码农之家](https://www.xz577.com/e/cxsj/)

[Java电子书大全](https://www.ebook23.com/)

[libgen](http://libgen.is/)

[吴川斌的博客](https://www.mr-wu.cn/downloads/)

[我的打包分享](http://mydbfx.com/)

## 搜索

[小不点搜索](https://www.xiaoss.net/)

[盘么么](http://www.panmeme.com/)

[Java分享网](http://www.javaxz.com/)

[hello girl](https://www.jqhtml.com/down/)

[小可搜搜](https://www.xiaokesoso.com/)

[白玉搜一搜](http://www.baiyu.tech/)

[蓝奏](http://www.lanzous.com/)

[盘发网盘](https://m.panfa.net/)

[如风搜](http://www.rufengso.net/)

[磁力点点搜索](http://www.torrent.org.cn/bd)

[资源共享网](http://www.86clouds.com/)

## 视频

[videofk](https://www.videofk.com/)

[人人译世界](http://www.1sj.tv/)

[savefrom.net](https://en.savefrom.net/)

[bitdownloader](https://bitdownloader.com/)

## 设计

[稿定设计](https://www.gaoding.com/)

[爱给网](http://www.aigei.com/)

[Mixkit](https://mixkit.co/)

[pinterest](https://www.pinterest.com/)

## 字体

[360查字体](http://fonts.safe.360.cn/)

[字由](http://www.hellofont.cn/)

[求字体网](http://www.qiuziti.com/)

## 学习办公

[uzerMe](https://www.uzer.me/)

[wolframalpha](https://www.wolframalpha.com/)

[正版中国](https://getitfree.cn/)

[epubconverter](https://www.epubconverter.com/)

## 二次元

[喵窝](https://www.nyagal.com/)

[琉璃神社](http://www.llss.life/)

> 爬虫：[liulishenshe_crawler](https://github.com/risingsun1412/liulishenshe_crawler)

[pixiv](https://www.pixiv.net/)

## 历史

[全历史](https://www.allhistory.com/)

[发现中国](https://www.ageeye.cn/)

[中华珍宝馆](http://www.ltfc.net/)

## 图片

[pixabay](https://pixabay.com/)

[freepik](https://www.freepik.com/)

[pexels](https://www.pexels.com/)

[airpano](https://www.airpano.com/)

[zoommyapp](https://zoommyapp.com/)

[unsplash](https://unsplash.com/)

[wallhaven](https://wallhaven.cc/)

[instagram](https://www.instagram.com/)

## 软件下载

[腾龙工作室](https://www.tenlonstudio.com/)

[无所不藏](https://www.nocang.com/soft/)

[乐破解](https://www.lepojie.com/)

[Adobe 2020全家桶系列分享](http://hqled.net/6484.html)

[木木博客](https://www.liulinblog.com/ziyuan/software)

[ccava](https://www.ccava.net/category-44.html)

[精品绿色便携软件](https://www.portablesoft.org/)

[alternativeto](https://alternativeto.net/)

[amazing-apps](https://amazing-apps.gitbook.io/windows-apps-that-amaze-us/zh-cn)

[达夕博客]([https://www.daxiblog.com/%e8%bd%af%e4%bb%b6%e5%b7%a5%e5%85%b7/](https://www.daxiblog.com/软件工具/))

[Xshell v6.0.0.184 永久授权中文绿色版](https://masuit.com/178/ABBYY)

<div hidden="true">
## 你懂的

[pornhub](https://www.pornhub.com/)

[xvideos](https://www.xvideos.com/)

[porno800](https://porno800.com/)

[youjizz](https://www.youjizz.com/)

[adultxxx](http://www.adultxxx.xxx/)

[wz328](www.wz328.com)

[5meipai](https://www.5meipai.org/)

[ainterlagos](http://www.ainterlagos.com/)

[58av](http://58av.store/)

[333gen](https://333gen.com/)

[22cao](http://www.22cao.com/)

[91se](https://91se.cc/index/home.html)

[ef225](https://www.ef225.com/index/home.html)

> 发送任意邮件：haomaomi@mail.com 获取最新域名

[e27e](http://www.e27e.com/)

[bt7086](http://s1.pbnmdssb.top/pw/)

[xhamster](https://xhamster.com/)

[javhoo](https://www.javhoo.com/)

[含羞草研究所](http://www.hxctv65.com/)

[gezhilu](http://www.gezhilu.org/)

[1239uu](https://www.1239uu.com/)

[hhrrr3](https://hhrrr3.bid/)

[ffb16.com](http://www.67ggc.com/home.x)

[300avs](http://www.300avs.com/)

[kv2015](http://kv2015.com)

[huluwa520](http://huluwa520.com/)

[bzdesigner](http://www.bzdesigner.com/)

[firachina](http://www.firachina.com/)

[eryoga](http://eryoga.com/)

[sw360](http://www.sw360.xyz/)

[555dei](https://555dei.com/s02/index.html)

[cnyadu](http://www.cnyadu.com/)

[77tmm](http://www.77tmm.com:8888/)

[qm883](http://www.qm883.xyz/)

[yuepinggg](http://www.yuepinggg.cn/)

[黄鸭在线](https://iiiii11111lllllll1111.space/)

</div>

参考资料：

[最让你震惊的网站有哪些？](https://www.zhihu.com/question/20030360)

[10个精品软件下载网站-1](https://posts.careerengine.us/p/5c6622357f5ac923be6c8b2f)

[10个精品软件下载网站-2](https://posts.careerengine.us/p/5c6622307f5ac923be6c8b2b)

