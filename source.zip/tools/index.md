---
title: "开发常用工具集合"
date: 2018-12-21 21:34:10
type: "tools"
---

### 后端

#### Java

[JDK 历史版本下载归档：https://www.oracle.com/technetwork/java/javase/archive-139210.html](https://www.oracle.com/technetwork/java/javase/archive-139210.html)

[JDK 历史版本 API 归档：https://www.oracle.com/technetwork/java/api-141528.html](https://www.oracle.com/technetwork/java/api-141528.html)

[Java SE 1.8 API 文档：https://docs.oracle.com/javase/8/docs/api/](https://docs.oracle.com/javase/8/docs/api/)

[jad 下载：http://java-decompiler.github.io/](http://java-decompiler.github.io/)

[jmeter 下载：https://jmeter.apache.org/download_jmeter.cgi](https://jmeter.apache.org/download_jmeter.cgi)

[javafx-scene-builder 下载：https://javafx-scene-builder.informer.com/download/](https://javafx-scene-builder.informer.com/download/)

##### 框架

[spring 官网：https://spring.io/projects](https://spring.io/projects)

[tomcat 历史版本下载归档：https://archive.apache.org/dist/tomcat/](https://archive.apache.org/dist/tomcat/)

[Mybatis Plus 官方指南：https://mp.baomidou.com/guide/](https://mp.baomidou.com/guide/)

[maven 下载：https://maven.apache.org/download.cgi](https://maven.apache.org/download.cgi)

[dubbo 官方文档：http://dubbo.apache.org/zh-cn/docs/user/quick-start.html](http://dubbo.apache.org/zh-cn/docs/user/quick-start.html)

[maven 官方仓库：https://mvnrepository.com/](https://mvnrepository.com/)

#### Python

[python 下载：https://www.python.org/downloads/](https://www.python.org/downloads/)

#### Go

[go 下载：https://golang.google.cn/dl/](https://golang.google.cn/dl/)

[go官方文档：https://golang.google.cn/doc/](https://golang.google.cn/doc/)

[go 非英文文档归档：https://github.com/golang/go/wiki/NonEnglish](https://github.com/golang/go/wiki/NonEnglish)

#### DataBase

[MySQL 历史版本下载归档：https://downloads.mysql.com/archives/community/](https://downloads.mysql.com/archives/community/)

[heidisql 下载：https://www.heidisql.com/download.php](https://www.heidisql.com/download.php)

[navicat 下载：https://www.navicat.com/en/products](https://www.navicat.com/en/products)

[sqlyog-community 下载：https://github.com/webyog/sqlyog-community/wiki/Downloads](https://github.com/webyog/sqlyog-community/wiki/Downloads)

[mongdb 历史版本下载归档：https://www.mongodb.com/download-center/community](https://www.mongodb.com/download-center/community)

[RedisDesktopManager 源文件历史版本下载归档：https://github.com/uglide/RedisDesktopManager/releases](https://github.com/uglide/RedisDesktopManager/releases)

[redis-desktop-manager-0.8.8.384.exe 官方下载：https://github.com/uglide/RedisDesktopManager/releases/tag/0.8.8](https://github.com/uglide/RedisDesktopManager/releases/tag/0.8.8)

[redis windows 历史版本下载归档：https://github.com/microsoftarchive/redis/releases](https://github.com/microsoftarchive/redis/releases)

[postgresql 下载： https://www.postgresql.org/download/]( https://www.postgresql.org/download/ )

#### IDE

[STS3 历史版本下载归档：https://spring.io/tools3/sts/all/](https://spring.io/tools3/sts/all/)

[IDEA 官网：https://www.jetbrains.com/](https://www.jetbrains.com/)

[IDEA 主题下载：https://plugins.jetbrains.com/contest/intellij-themes/2019](https://plugins.jetbrains.com/contest/intellij-themes/2019)

[IDEA 主题下载：http://color-themes.com/?view=index](http://color-themes.com/?view=index)

[visual studio code 下载：https://code.visualstudio.com/download](https://code.visualstudio.com/download)

[visual studio code 官方文档：https://code.visualstudio.com/docs](https://code.visualstudio.com/docs)

#### C & C++

[codeblocks 下载：http://www.codeblocks.org/downloads/26](http://www.codeblocks.org/downloads/26)

[visual studio 下载：https://visualstudio.microsoft.com/zh-hans/vs/](https://visualstudio.microsoft.com/zh-hans/vs/)

[MinGW 下载：https://osdn.net/projects/mingw/releases/](https://osdn.net/projects/mingw/releases/)

#### 汇编

[MASM32 SDK 下载：http://www.masm32.com/download.htm](http://www.masm32.com/download.htm)

[ollydbg 下载：http://www.ollydbg.de/version2.html](http://www.ollydbg.de/version2.html)

[HxD 下载：https://mh-nexus.de/en/downloads.php?product=HxD20](https://mh-nexus.de/en/downloads.php?product=HxD20)

[010editor 下载：http://www.sweetscape.com/download/010editor/](http://www.sweetscape.com/download/010editor/)

#### perl

[perl 下载：https://www.perl.org/get.html](https://www.perl.org/get.html)

#### ruby

[ruby 下载：https://www.ruby-lang.org/en/downloads/](https://www.ruby-lang.org/en/downloads/)

#### scala

[scala 下载：https://www.scala-lang.org/download/](https://www.scala-lang.org/download/)

#### plantuml

[plantuml 官网：http://plantuml.com/zh/](http://plantuml.com/zh/)

#### OAuth 2.0

[OAuth 2.0 官网：https://oauth.net/2/](https://oauth.net/2/)

#### kakfa

[kakfa 下载：http://kafka.apache.org/downloads](http://kafka.apache.org/downloads)

[kakfa 官方文档：http://kafka.apache.org/documentation/](http://kafka.apache.org/documentation/)

[kafka-manager 下载：https://github.com/yahoo/kafka-manager/releases/](https://github.com/yahoo/kafka-manager/releases/)

#### zookeeper

[zookeeper 下载：https://www.apache.org/dyn/closer.cgi/zookeeper/](https://www.apache.org/dyn/closer.cgi/zookeeper/)

[镜像下载：http://mirror.bit.edu.cn/apache/zookeeper/](http://mirror.bit.edu.cn/apache/zookeeper/)

[ZooInspector 下载：https://issues.apache.org/jira/secure/attachment/12436620/ZooInspector.zip](https://issues.apache.org/jira/secure/attachment/12436620/ZooInspector.zip)

[zktools 官方文档： https://zktools.readthedocs.io/en/latest/index.html#installing](https://zktools.readthedocs.io/en/latest/index.html#installing)

#### nginx

[nginx 下载：https://nginx.org/en/download.html](https://nginx.org/en/download.html)

[nginx 官方文档：https://nginx.org/en/docs/](https://nginx.org/en/docs/)

#### elastic

[elastic 系列产品下载：https://www.elastic.co/cn/downloads/](https://www.elastic.co/cn/downloads/)

[elasticsearch-head 下载：https://github.com/mobz/elasticsearch-head/](https://github.com/mobz/elasticsearch-head/)

#### kubernetes

[kubernetes 官方文档：https://kubernetes.io/docs/setup/](https://kubernetes.io/docs/setup/)

#### jenkins

[jenkins 官方文档：https://jenkins.io/zh/doc/](https://jenkins.io/zh/doc/)

#### gitlab

[gitlab 下载：https://packages.gitlab.com/gitlab/gitlab-ce/](https://packages.gitlab.com/gitlab/gitlab-ce/)

#### grafana

[grafana 下载：https://grafana.com/get](https://grafana.com/get)

[grafana 官方文档：https://grafana.com/docs/](https://grafana.com/docs/)

#### prometheus

[prometheus 下载：https://prometheus.io/download/](https://prometheus.io/download/)

[prometheus 官方文档：https://prometheus.io/docs/prometheus/latest/getting_started/](https://prometheus.io/docs/prometheus/latest/getting_started/)

#### sonar

[sonar 下载：https://www.sonarqube.org/downloads/](https://www.sonarqube.org/downloads/)

[sonar 官方文档：https://docs.sonarqube.org/latest/](https://docs.sonarqube.org/latest/)

#### consul

[consul 下载：https://www.consul.io/downloads.html](https://www.consul.io/downloads.html)

[consul 官方文档：https://www.consul.io/docs/index.html](https://www.consul.io/docs/index.html)

#### zipkin

[zipkin 官方文档：https://zipkin.io/pages/quickstart.html](https://zipkin.io/pages/quickstart.html)

#### django

[django 下载：https://www.djangoproject.com/download/](https://www.djangoproject.com/download/)

### 前端

#### HTML

[w3school在线教程：https://www.w3school.com.cn/](https://www.w3school.com.cn/)

[MDN 学习 Web 开发：https://developer.mozilla.org/zh-CN/docs/Learn](https://developer.mozilla.org/zh-CN/docs/Learn)

[JavaScript 教程：https://www.w3school.com.cn/js/index.asp](https://www.w3school.com.cn/js/index.asp)

[TypeScript 官方文档：https://www.tslang.cn/docs/home.html](https://www.tslang.cn/docs/home.html )

[ECMAScript 6 入门：https://es6.ruanyifeng.com/](https://es6.ruanyifeng.com/)

#### CSS

[bootstrap 官网中文教程：https://v3.bootcss.com/getting-started/](https://v3.bootcss.com/getting-started/)

[fontawesome 官网：http://fontawesome.dashgame.com/](http://fontawesome.dashgame.com/)

#### node.js

[nodejs 下载：https://nodejs.org/en/download/](https://nodejs.org/en/download/)

#### vue.js

[vuejs 官方文档：https://cn.vuejs.org/v2/guide/](https://cn.vuejs.org/v2/guide/)

[element-ui 官方文档：https://element.eleme.cn/#/zh-CN/component/installation](https://element.eleme.cn/#/zh-CN/component/installation)

#### angular2

[angular2 官方文档：https://angular.cn/docs](https://angular.cn/docs)

#### echarts.js 

[echartsjs 官方文档：https://www.echartsjs.com/zh/tutorial.html](https://www.echartsjs.com/zh/tutorial.html)

#### npm

[淘宝 NPM 镜像：https://npm.taobao.org/](https://npm.taobao.org/)

#### react

[react 官方文档：https://react.docschina.org/tutorial/tutorial.html](https://react.docschina.org/tutorial/tutorial.html)

#### layui

[layui 官方文档：https://www.layui.com/doc/](https://www.layui.com/doc/)

### Mock

#### json-server

[json-server 下载：https://github.com/typicode/json-server](https://github.com/typicode/json-server)

#### WireMock

[WireMock 官方文档：http://wiremock.org/docs/getting-started/](http://wiremock.org/docs/getting-started/)

### Linux & Windows

[centos 历史版本下载归档：https://wiki.centos.org/Download](https://wiki.centos.org/Download)

[MSDN, 我告诉你：https://msdn.itellyou.cn/](https://msdn.itellyou.cn/)

[xshell 系列产品下载：https://www.netsarang.com/en/all-downloads/](https://www.netsarang.com/en/all-downloads/)

[xshell 颜色主题下载：https://github.com/netsarang/Xshell-ColorScheme](https://github.com/netsarang/Xshell-ColorScheme)

[mobaxterm 下载：https://mobaxterm.mobatek.net/download.html](https://mobaxterm.mobatek.net/download.html)

[putty 下载：https://www.chiark.greenend.org.uk/~sgtatham/putty/latest.html](https://www.chiark.greenend.org.uk/~sgtatham/putty/latest.html)

[putty 颜色主题下载：https://github.com/AlexAkulov/putty-color-themes](https://github.com/AlexAkulov/putty-color-themes)

[vmware 系列产品下载：https://my.vmware.com/cn/web/vmware/downloads](https://my.vmware.com/cn/web/vmware/downloads)

[filezilla 下载：https://filezilla-project.org/download.php](https://filezilla-project.org/download.php)

### 镜像

#### 国内开源镜像

[阿里巴巴开源镜像站：https://opsx.alibaba.com/mirror](https://opsx.alibaba.com/mirror)

[网易开源镜像站： http://mirrors.163.com/ ]( http://mirrors.163.com/ )

[搜狐开源镜像：http://mirrors.sohu.com/ ]( http://mirrors.sohu.com/ )

[浙江大学开源镜像站： http://mirrors.zju.edu.cn/ ]( http://mirrors.zju.edu.cn/ )

[ 中国科学技术大学开源镜像站： http://mirrors.ustc.edu.cn/]( http://mirrors.ustc.edu.cn/)

[中科技大学开源镜像站： http://mirror.hust.edu.cn/ ]( http://mirror.hust.edu.cn/ )

 [清华大学开源软件镜像站：https://mirrors.tuna.tsinghua.edu.cn/](https://mirrors.tuna.tsinghua.edu.cn/)

####  国外官方镜像列表状态地址

[CentOS：http://mirror-status.centos.org/](http://mirror-status.centos.org/)

[Archlinux：https://www.archlinux.org/mirrors/status/](https://www.archlinux.org/mirrors/status/)

[Ubuntu：https://launchpad.net/ubuntu/+cdmirrors](https://launchpad.net/ubuntu/+cdmirrors)

[Debian：http://mirror.debian.org/status.html](http://mirror.debian.org/status.html)

[Fedora Linux/Fedora EPEL：https://admin.fedoraproject.org/mirrormanager/mirrors](https://admin.fedoraproject.org/mirrormanager/mirrors)

[Apache：http://www.apache.org/mirrors/](http://www.apache.org/mirrors/)

[Cygwin：https://www.cygwin.com/mirrors.html](https://www.cygwin.com/mirrors.html)

### 浏览器

#### firefox

[firefox 国际版下载：https://www.mozilla.org/en-US/firefox/all/#product-desktop-release](https://www.mozilla.org/en-US/firefox/all/#product-desktop-release) *firefox 浏览器切勿下载中文版*

[firefox 各国语言版下载归档：https://www.mozilla.org/en-US/firefox/organizations/all/](https://www.mozilla.org/en-US/firefox/organizations/all/) *firefox 浏览器切勿下载中文版*

[firefox 开发者版各国语言版下载归档：https://www.mozilla.org/en-US/firefox/developer/all/](https://www.mozilla.org/en-US/firefox/developer/all/)

#### chrome

[chrome 下载：https://www.google.cn/chrome/](https://www.google.cn/chrome/)

[chrome 开发者版下载：https://www.google.cn/chrome/dev/](https://www.google.cn/chrome/dev/)

[chrome 扩展应用商店：https://chrome.google.com/webstore/category/extensions](https://chrome.google.com/webstore/category/extensions)

### 其他

#### 测试

[postman 下载：https://www.getpostman.com/downloads/](https://www.getpostman.com/downloads/)

[ApacheBench 下载：https://archive.apache.org/dist/httpd/](https://archive.apache.org/dist/httpd/)

[IETester 下载：https://www.my-debugbar.com/wiki/IETester/HomePage](https://www.my-debugbar.com/wiki/IETester/HomePage)

#### 截图

[snipaste 下载：https://www.snipaste.com/download.html](https://www.snipaste.com/download.html)

[picpick 下载：https://picpick.app/en/download](https://picpick.app/en/download)

[gifcam 下载：http://blog.bahraniapps.com/gifcam/#download](http://blog.bahraniapps.com/gifcam/#download)

#### 电子书阅读器

[calibre 下载：https://calibre-ebook.com/download](https://calibre-ebook.com/download)

#### 视频播放器

[vlc 播放器下载：https://www.videolan.org/vlc/index.html](https://www.videolan.org/vlc/index.html)

[pot player 播放器下载：https://daumpotplayer.com/download/](https://daumpotplayer.com/download/)

#### 文本编辑器

[notepad++ 下载：https://notepad-plus-plus.org/downloads/](https://notepad-plus-plus.org/downloads/)

[vim 下载：https://www.vim.org/download.php](https://www.vim.org/download.php)

[Sublime Text 3 3 下载：http://www.sublimetext.com/3](http://www.sublimetext.com/3)

[typora 下载：https://www.typora.io/#download](https://www.typora.io/#download)

[typora 主题下载：http://theme.typora.io/](http://theme.typora.io/)

[sumatrapdf 下载：https://www.sumatrapdfreader.org/download-free-pdf-viewer.html](https://www.sumatrapdfreader.org/download-free-pdf-viewer.html)

#### 录屏

[OBS Studio 下载：https://obsproject.com/download](https://obsproject.com/download)

[Core Temp 下载：https://www.alcpu.com/CoreTemp/](https://www.alcpu.com/CoreTemp/)

[system explorer 下载：http://systemexplorer.net/](http://systemexplorer.net/)

#### GIT

[git 下载：https://git-scm.com/downloads](https://git-scm.com/downloads)

[source tree 下载：https://www.sourcetreeapp.com/](https://www.sourcetreeapp.com/)

[tortoisegit 下载：https://tortoisegit.org/download/](https://tortoisegit.org/download/)

#### 文件比较

[winmerge 下载：https://winmerge.org/downloads/?lang=en](https://winmerge.org/downloads/?lang=en)

[Beyond Compare 下载：http://www.scootersoftware.com/download.php](http://www.scootersoftware.com/download.php)

#### 输入法

[RIME／中州韵输入法引擎 下载：https://rime.im/download/](https://rime.im/download/)

#### 网络抓包

[wireshark 下载：https://www.wireshark.org/download.html](https://www.wireshark.org/download.html)

[fiddler 下载：https://www.telerik.com/download/fiddler](https://www.telerik.com/download/fiddler)