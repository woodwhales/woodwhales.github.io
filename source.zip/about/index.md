---
title: "ABOUT"
date: 2018-12-21 21:34:10
type: "about"
---

<div class="about-page">
<h3>关于木鲸鱼</h3><blockquote>编程的魅力在于**控制重复**和**创造美好**。</blockquote>菜鸟级程序员一枚，爱设计，更爱编程。
<h3>关于博客</h3><blockquote>好记性不如烂笔头</blockquote>要学的东西太多，学完最好记个笔记，以防忘记了，还能赶紧来这再捡起来。
<center><h5>欢迎关注「木鲸鱼」公众号</h5></center>
</div>